﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class ARegister : MaterialSkin.Controls.MaterialForm
    {
        SqlDataAdapter adapt;
        String gen = "";
        String imgloc = "";
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");
        // Method for opening the connection to database.
        public ARegister()
        {
            InitializeComponent();
           
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }
     
    
        private void URegister_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cafeDataSet3.admin' table. You can move, or remove it, as needed.
            this.adminTableAdapter.Fill(this.cafeDataSet3.admin);

            con.Open();
            adapt = new SqlDataAdapter("Select * From [dbo].[admin]", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["EId"] = "Select Id";
            dt.Rows.InsertAt(dr, 0);
            comboBox1.ValueMember = "EId";
            comboBox1.DisplayMember = "EId";
            comboBox1.DataSource = dt;
            con.Close();

        
        }
 
        

        private void GroupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void MaterialLabel1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialDivider1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

       

        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {
           
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
           if (materialRadioButton1.Checked)
            {
                gen = "Male";
            }
            if (materialRadioButton2.Checked)
            {
                gen = "Female";
            }
        
            cmd.CommandText = "insert into admin values('" + materialSingleLineTextField1.Text + "','" + materialSingleLineTextField2.Text + "','" + materialSingleLineTextField3.Text + "','" + materialSingleLineTextField4.Text + "','" + materialSingleLineTextField5.Text + "','" + textBox1.Text + "','" + materialSingleLineTextField6.Text + "','" + materialSingleLineTextField7.Text + "','" + gen + "')";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record inserted successfully");
           



        }
      
     
        private void MaterialSingleLineTextField9_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField10_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            string selectQuery = "SELECT * FROM [dbo].[admin]";
            SqlCommand cmd = new SqlCommand(selectQuery, con);
            adapt = new SqlDataAdapter(cmd);

            DataTable table = new DataTable();

            

            adapt.Fill(table);

            dataGridView1.DataSource = table;

           
          
            }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          /*pictureBox1.Image = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            materialSingleLineTextField2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            materialSingleLineTextField3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            materialSingleLineTextField4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            materialSingleLineTextField5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            materialSingleLineTextField6.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            materialSingleLineTextField7.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            materialSingleLineTextField8.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            
            */
           
            
        }

        private void materialRaisedButton3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from admin  where EId='" + materialSingleLineTextField1.Text + "'";
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("record deleted successfully");

        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            materialSingleLineTextField1.Text = "";
            materialSingleLineTextField2.Text = "";
            materialSingleLineTextField3.Text = "";
            materialSingleLineTextField4.Text = "";
            materialSingleLineTextField5.Text = "";
            textBox1.Text = "";
            materialSingleLineTextField6.Text = "";
            materialSingleLineTextField7.Text = "";  
        }

        private void materialRaisedButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void materialRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tableTableAdapter1.FillBy(this.cafeDataSet1.Table);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton7_Click(object sender, EventArgs e)
        {
            con.Open();

            adapt = new SqlDataAdapter("SELECT *  FROM [dbo].[admin] where EId='" + comboBox1.SelectedValue + "'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
           this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        }

        private void materialRaisedButton6_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imgloc = dialog.FileName.ToString();
                pictureBox1.ImageLocation = imgloc;

            }  
        }

        private void materialRaisedButton8_Click(object sender, EventArgs e)
        {
            if (materialRadioButton1.Checked)
            {
                gen = "Male";
            }
            if (materialRadioButton2.Checked)
            {
                gen = "Female";
            }

            SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "UPDATE admin SET EId='" + materialSingleLineTextField1.Text + "',passwd='" + materialSingleLineTextField2.Text + "',fnm='" + materialSingleLineTextField3.Text + "',mnm='" + materialSingleLineTextField4.Text + "',lnm='" + materialSingleLineTextField5.Text + "',address='" + textBox1.Text + "',cont='" + materialSingleLineTextField6.Text + "',eml='" + materialSingleLineTextField7.Text + "',gend='" + gen + "' where EId='" + materialSingleLineTextField1.Text + "'";
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        MessageBox.Show("record updated successfully");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField6_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField7_Click(object sender, EventArgs e)
        {

        }



       



    }
}
