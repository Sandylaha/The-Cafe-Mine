﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class Stock : MaterialSkin.Controls.MaterialForm

    {
        SqlDataAdapter adapt;
        String gen = "";
        String imgloc = "";
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");
        public Stock()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        
    }

    private void Stock_Load(object sender, EventArgs e)
        {
            con.Open();
            adapt = new SqlDataAdapter("Select * From [dbo].[stock]", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["PId"] = "Select Id";
            dt.Rows.InsertAt(dr, 0);
            comboBox1.ValueMember = "PId";
            comboBox1.DisplayMember = "PId";
            comboBox1.DataSource = dt;
            con.Close();
        }

        private void GroupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void GroupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void MaterialLabel2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel3_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel4_Click(object sender, EventArgs e)
        {

        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MaterialRaisedButton4_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField5_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField8_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField7_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton3_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton2_Click_1(object sender, EventArgs e)
        {
            materialSingleLineTextField1.Text = "";
            materialSingleLineTextField2.Text = "";
            materialSingleLineTextField3.Text = "";
            materialSingleLineTextField4.Text = "";
            materialSingleLineTextField5.Text = "";
            materialSingleLineTextField6.Text = "";
            materialSingleLineTextField7.Text = "";
            materialSingleLineTextField8.Text = "";  

        }

        private void materialRaisedButton4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void materialRaisedButton6_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into stock values('" + materialSingleLineTextField1.Text + "','" + materialSingleLineTextField2.Text + "','" + materialSingleLineTextField3.Text + "','" + materialSingleLineTextField4.Text + "','" + materialSingleLineTextField5.Text + "','" + materialSingleLineTextField6.Text + "','" + materialSingleLineTextField7.Text + "','" + materialSingleLineTextField8.Text + "')";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record inserted successfully");

        }

        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from stock", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void materialRaisedButton3_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from stock  where PId='" + materialSingleLineTextField1.Text + "'";
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("record deleted successfully");
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            con.Open();

            adapt = new SqlDataAdapter("SELECT *  FROM stock where PId='" + comboBox1.SelectedValue + "'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        }

        private void materialRaisedButton8_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE stock SET PId='" + materialSingleLineTextField1.Text + "',Pname='" + materialSingleLineTextField2.Text + "',Brand='" + materialSingleLineTextField3.Text + "',city='" + materialSingleLineTextField4.Text + "',unit='" + materialSingleLineTextField5.Text + "',rate='" + materialSingleLineTextField6.Text + "',quan='" + materialSingleLineTextField7.Text + "',amount='" + materialSingleLineTextField8.Text + "' where PId='" + materialSingleLineTextField1.Text + "'";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record updated successfully");
        }
    }
}
