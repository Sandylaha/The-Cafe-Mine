﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web;
using System.Net;
using System.Net.Mail;


namespace The_Cafe_Mine
{
    public partial class Email : MaterialSkin.Controls.MaterialForm
    {
        public Email()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        
    }

        private void Email_Load(object sender, EventArgs e)
        {

        }

        private void MaterialLabel3_Click(object sender, EventArgs e)
        {
            

        }

        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {
            try
            {

                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("sandiplaha206@gmail.com");
                msg.To.Add(materialSingleLineTextField2.Text);
                msg.Subject = materialSingleLineTextField3.Text;
                msg.Body = textBox1.Text;
                msg.Attachments.Add(new Attachment(materialSingleLineTextField4.Text));

                SmtpClient smt = new SmtpClient();
                smt.Host = "smtp.gmail.com";
                System.Net.NetworkCredential ntcd = new NetworkCredential();
                ntcd.UserName = "sandiplaha206@gmail.com";
                ntcd.Password = "sandipcorporateid";
                smt.Credentials = ntcd;
                smt.EnableSsl = true;
                smt.Port = 587;
                smt.Send(msg);

                MessageBox.Show("Email Sent");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void MaterialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton2_Click(object sender, EventArgs e)
        {
            materialSingleLineTextField2.Text = string.Empty;
            materialSingleLineTextField3.Text = string.Empty;
            textBox1.Text = string.Empty;
            materialSingleLineTextField4.Text = string.Empty;

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string picPath = ofd.FileName.ToString();
                materialSingleLineTextField4.Text = picPath;
            }
        }
        

    }
}
