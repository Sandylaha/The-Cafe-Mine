﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class Supplier : MaterialSkin.Controls.MaterialForm
    {
        SqlDataAdapter adapt;

       
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");
        public Supplier()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        
    }

        private void GroupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Supplier_Load(object sender, EventArgs e)
        {
            con.Open();
            adapt = new SqlDataAdapter("Select * From [dbo].[supplier]", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["sid"] = "Select Id";
            dt.Rows.InsertAt(dr, 0);
            comboBox1.ValueMember = "sid";
            comboBox1.DisplayMember = "sid";
            comboBox1.DataSource = dt;
            con.Close();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton3_Click(object sender, EventArgs e)
        {

        }

        private void GroupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void MaterialLabel2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel4_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel6_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel5_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel7_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField3_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField7_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField8_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField6_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            
        }

        private void materialRaisedButton1_Click_1(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into supplier values('" + sid.Text + "','" + sfnm.Text + "','" + smnm.Text + "','" + slnm.Text + "','" + address.Text + "','" + city.Text + "','" + emailid.Text + "','" + contact.Text + "','" + info.Text + "','" + pin.Text + "')";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record inserted successfully");
        }

        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from supplier", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void materialRaisedButton3_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from supplier  where sid='" + sid.Text + "'";
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("record deleted successfully");
        }

        private void materialRaisedButton8_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE supplier SET sid='" + sid.Text + "',sfnm='" + sfnm.Text + "',smnm='" + smnm.Text + "',slnm='" + slnm.Text + "',ad='" + address.Text + "',city='" + city.Text + "',em='" + emailid.Text + "',co='" + contact.Text + "',det='" + info.Text + "',pin='" + pin.Text + "' where sid='" + sid.Text + "'";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record updated successfully");
        }

        private void materialRaisedButton2_Click_1(object sender, EventArgs e)
        {
            sid.Text = "";
            sfnm.Text = "";
            smnm.Text = "";
            slnm.Text = "";
            address.Text = "";
            city.Text = "";
            emailid.Text = "";
            contact.Text = "";
            info.Text = "";
            pin.Text = "";  


        }

        private void materialRaisedButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void materialRaisedButton7_Click(object sender, EventArgs e)
        {
            con.Open();

            adapt = new SqlDataAdapter("SELECT *  FROM supplier where sid='" + comboBox1.SelectedValue + "'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        }
    }
}
