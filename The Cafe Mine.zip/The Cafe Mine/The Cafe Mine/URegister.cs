﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class URegister : MaterialSkin.Controls.MaterialForm
    {

        SqlDataAdapter adapt;
        String gen = "";
        String imgloc = "";
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");

        public URegister()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }

        private void URegister_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cafeDataSet5.user' table. You can move, or remove it, as needed.
            this.userTableAdapter.Fill(this.cafeDataSet5.user);
            con.Open();
            adapt = new SqlDataAdapter("Select * From [dbo].[user]", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["EId"] = "Select Id";
            dt.Rows.InsertAt(dr, 0);
            comboBox1.ValueMember = "EId";
            comboBox1.DisplayMember = "EId";
            comboBox1.DataSource = dt;
            con.Close();
        }

        private void GroupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void MaterialLabel1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialDivider1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField9_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void materialRaisedButton1_Click_1(object sender, EventArgs e)
        {
            String gen = "";
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            if (materialRadioButton1.Checked)
            {
                gen = "Male";
            }
            if (materialRadioButton2.Checked)
            {
                gen = "Female";
            }
        /*   byte[] images = null;
            FileStream fs = new FileStream(imgloc, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            images = br.ReadBytes((int)fs.Length);*/
            cmd.CommandText = "insert into [dbo].[user] values('" + Id.Text + "','" + pwd.Text + "','" + fname.Text + "','" + mname.Text + "','" + lname.Text + "','" + txt.Text + "','" + mob.Text + "','" + email.Text + "','" + gen + "')";

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record inserted successfully");
        }

        private void materialRaisedButton6_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imgloc = dialog.FileName.ToString();
                pictureBox1.ImageLocation = imgloc;

            }  

        }

        private void materialRaisedButton7_Click(object sender, EventArgs e)
        {
            con.Open();

            adapt = new SqlDataAdapter("SELECT *  FROM [dbo].[user] where EId='" + comboBox1.SelectedValue + "'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
           this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            Id.Text = "";
            pwd.Text = "";
            fname.Text = "";
            mname.Text = "";
            lname.Text = "";
            txt.Text = "";
            mob.Text = "";
            email.Text = "";  
        }

        private void materialRaisedButton3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from [dbo].[user] where EId='" + Id.Text + "'";
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("record deleted successfully");
        }

        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from [dbo].[user]", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void materialSingleLineTextField3_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField6_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton8_Click(object sender, EventArgs e)
        {
            if (materialRadioButton1.Checked)
            {
                gen = "Male";
            }
            if (materialRadioButton2.Checked)
            {
                gen = "Female";
            }

            SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "UPDATE [dbo].[user] SET EId='" + Id.Text + "',pwd='" + pwd.Text + "',fnm='" + fname.Text + "',mnm='" + mname.Text + "',lnm='" + lname.Text + "',txt='" + txt.Text + "',con='" + mob.Text + "',eml='" + email.Text + "',gend='" + gen + "' where EId='" + Id.Text + "'";
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        MessageBox.Show("record updated successfully");
        }

        private void materialRaisedButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
      
        }
    

