﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class Orders : MaterialSkin.Controls.MaterialForm
    {
    
        SqlDataAdapter da;
        DataTable dt;
        String gen = "";
        String imgloc = "";
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");
        // Method for opening the connection to database.
        public Orders()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }
     

        private void Orders_Load(object sender, EventArgs e)
        {
            con.Open();
            da = new SqlDataAdapter("Select * From [dbo].[orders]", con);
            dt = new DataTable();
            da.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["Id"] = "Select Product";
            dt.Rows.InsertAt(dr, 0);
            comboBox1.ValueMember = "Id";
            comboBox1.DisplayMember = "Id";
            comboBox1.DataSource = dt;
            con.Close();

        }

        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            con.Open();
            DataTable dt = new DataTable();
            da = new SqlDataAdapter("select * from [dbo].[orders]", con);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void materialRaisedButton7_Click(object sender, EventArgs e)
        {
            con.Open();

            da = new SqlDataAdapter("SELECT *  FROM [dbo].[orders] where Id='" + comboBox1.SelectedValue + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            
        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
