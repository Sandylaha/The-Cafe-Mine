﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class Login : MaterialSkin.Controls.MaterialForm
    {

        
        public Login()
        {

            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }


        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {



            if (materialRadioButton1.Checked)
            {

                if (string.IsNullOrEmpty(this.materialSingleLineTextField1.Text) | string.IsNullOrEmpty(this.materialSingleLineTextField2.Text))
                {
                    MessageBox.Show("provide User Name and Password");
                }

                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");

                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[admin] WHERE EId = '" + materialSingleLineTextField1.Text + "' and passwd = '" + materialSingleLineTextField2.Text + "'", con);

                SqlDataReader dr = default(SqlDataReader);
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while ((dr.Read()) == true)
                {
                    string id = dr["EId"].ToString();
                    string passwd = dr["passwd"].ToString();
                    if ((materialSingleLineTextField1.Text.Trim() == id.Trim()) & (materialSingleLineTextField2.Text.Trim() == passwd.Trim()))
                    {
                        MessageBox.Show("*** Login Successful ***");
                        AMainmenu reg = new AMainmenu();
                        reg.ShowDialog();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Access Denied!!");
                    }
                }
                dr.Close();
                con.Close();
            }


            else  if (materialRadioButton2.Checked)
            {

                if (string.IsNullOrEmpty(this.materialSingleLineTextField1.Text) | string.IsNullOrEmpty(this.materialSingleLineTextField2.Text))
                {
                    MessageBox.Show("provide User Name and Password");
                }


                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");

                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM  [dbo].[user] WHERE EId = '" + materialSingleLineTextField1.Text + "' and pwd = '" + materialSingleLineTextField2.Text + "'", con);

                SqlDataReader dr = default(SqlDataReader);
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while ((dr.Read()) == true)
                {
                    string id = dr["EId"].ToString();
                    string passwd = dr["pwd"].ToString();
                    if ((materialSingleLineTextField1.Text.Trim() == id.Trim()) & (materialSingleLineTextField2.Text.Trim() == passwd.Trim()))
                    {
                        MessageBox.Show("*** Login Successful ***");
                        EMainmenu reg = new EMainmenu();
                        reg.ShowDialog();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Access Denied!!");
                    }
                }
                dr.Close();
                con.Close();
            }










            else
            {
                MessageBox.Show("Choose Admin or Employee");

            }
        }
           

    

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton2_Click(object sender, EventArgs e)
        {
            materialRadioButton1.Checked = false;
            materialRadioButton2.Checked = false;

            materialSingleLineTextField1.Text = string.Empty;
            materialSingleLineTextField2.Text = string.Empty;
        }

        private void MaterialRaisedButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MaterialRaisedButton4_Click(object sender, EventArgs e)
        {
            if (materialRadioButton1.Checked)
            {
                ARegister reg = new ARegister();
                reg.ShowDialog();
            }
            else if (materialRadioButton2.Checked)
            {
                URegister reg = new URegister();
                reg.ShowDialog();
            }
            else
            {
                MessageBox.Show("Choose Admin or Employee");
            }

        }

        private void MaterialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }
    }
}