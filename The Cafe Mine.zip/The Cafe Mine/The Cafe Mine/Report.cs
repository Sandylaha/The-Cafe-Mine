﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace The_Cafe_Mine
{
    public partial class Report : MaterialSkin.Controls.MaterialForm
    {
        SqlDataAdapter da;
        DataTable dt;
        String gen = "";

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");
        // Method for opening the connection to database.
        public Report()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }
        private void Billings_Load(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            DateTime fromDate, toDate;

            DateTime.TryParse(dateTimePicker1.Text, out fromDate);
            DateTime.TryParse(dateTimePicker2.Text, out toDate);
            con.Open();
            DataTable dt = new DataTable();
            da = new SqlDataAdapter("select * from [dbo].[orders] where date between '" + dateTimePicker1.Text + "' and '" + dateTimePicker2.Text.ToString() + "' ", con);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {

            
        }
       
    }
    }
