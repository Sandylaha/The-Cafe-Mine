﻿namespace The_Cafe_Mine
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.sid = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.contact = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.emailid = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.pin = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.city = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.info = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.slnm = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.smnm = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.sfnm = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel7 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.materialRaisedButton7 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialSingleLineTextField9 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.materialRaisedButton8 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialSingleLineTextField8 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialRaisedButton4 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton5 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton3 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton2 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.sid);
            this.groupBox1.Controls.Add(this.contact);
            this.groupBox1.Controls.Add(this.emailid);
            this.groupBox1.Controls.Add(this.pin);
            this.groupBox1.Controls.Add(this.city);
            this.groupBox1.Controls.Add(this.info);
            this.groupBox1.Controls.Add(this.address);
            this.groupBox1.Controls.Add(this.slnm);
            this.groupBox1.Controls.Add(this.smnm);
            this.groupBox1.Controls.Add(this.sfnm);
            this.groupBox1.Controls.Add(this.materialLabel7);
            this.groupBox1.Controls.Add(this.materialLabel6);
            this.groupBox1.Controls.Add(this.materialLabel5);
            this.groupBox1.Controls.Add(this.materialLabel4);
            this.groupBox1.Controls.Add(this.materialLabel3);
            this.groupBox1.Controls.Add(this.materialLabel2);
            this.groupBox1.Controls.Add(this.materialLabel1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DarkOrange;
            this.groupBox1.Location = new System.Drawing.Point(12, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(571, 369);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Supplier Details";
            this.groupBox1.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // sid
            // 
            this.sid.Depth = 0;
            this.sid.Hint = "";
            this.sid.Location = new System.Drawing.Point(141, 29);
            this.sid.MouseState = MaterialSkin.MouseState.HOVER;
            this.sid.Name = "sid";
            this.sid.PasswordChar = '\0';
            this.sid.SelectedText = "";
            this.sid.SelectionLength = 0;
            this.sid.SelectionStart = 0;
            this.sid.Size = new System.Drawing.Size(157, 23);
            this.sid.TabIndex = 18;
            this.sid.UseSystemPasswordChar = false;
            this.sid.Click += new System.EventHandler(this.materialSingleLineTextField8_Click);
            // 
            // contact
            // 
            this.contact.Depth = 0;
            this.contact.Hint = "";
            this.contact.Location = new System.Drawing.Point(125, 269);
            this.contact.MouseState = MaterialSkin.MouseState.HOVER;
            this.contact.Name = "contact";
            this.contact.PasswordChar = '\0';
            this.contact.SelectedText = "";
            this.contact.SelectionLength = 0;
            this.contact.SelectionStart = 0;
            this.contact.Size = new System.Drawing.Size(156, 23);
            this.contact.TabIndex = 17;
            this.contact.UseSystemPasswordChar = false;
            this.contact.Click += new System.EventHandler(this.MaterialSingleLineTextField7_Click);
            // 
            // emailid
            // 
            this.emailid.Depth = 0;
            this.emailid.Hint = "";
            this.emailid.Location = new System.Drawing.Point(125, 224);
            this.emailid.MouseState = MaterialSkin.MouseState.HOVER;
            this.emailid.Name = "emailid";
            this.emailid.PasswordChar = '\0';
            this.emailid.SelectedText = "";
            this.emailid.SelectionLength = 0;
            this.emailid.SelectionStart = 0;
            this.emailid.Size = new System.Drawing.Size(202, 23);
            this.emailid.TabIndex = 16;
            this.emailid.UseSystemPasswordChar = false;
            this.emailid.Click += new System.EventHandler(this.materialSingleLineTextField6_Click);
            // 
            // pin
            // 
            this.pin.Depth = 0;
            this.pin.Hint = "";
            this.pin.Location = new System.Drawing.Point(427, 181);
            this.pin.MouseState = MaterialSkin.MouseState.HOVER;
            this.pin.Name = "pin";
            this.pin.PasswordChar = '\0';
            this.pin.SelectedText = "";
            this.pin.SelectionLength = 0;
            this.pin.SelectionStart = 0;
            this.pin.Size = new System.Drawing.Size(108, 23);
            this.pin.TabIndex = 15;
            this.pin.UseSystemPasswordChar = false;
            // 
            // city
            // 
            this.city.Depth = 0;
            this.city.Hint = "";
            this.city.Location = new System.Drawing.Point(125, 181);
            this.city.MouseState = MaterialSkin.MouseState.HOVER;
            this.city.Name = "city";
            this.city.PasswordChar = '\0';
            this.city.SelectedText = "";
            this.city.SelectionLength = 0;
            this.city.SelectionStart = 0;
            this.city.Size = new System.Drawing.Size(156, 23);
            this.city.TabIndex = 14;
            this.city.UseSystemPasswordChar = false;
            this.city.Click += new System.EventHandler(this.materialSingleLineTextField4_Click);
            // 
            // info
            // 
            this.info.Location = new System.Drawing.Point(125, 309);
            this.info.Multiline = true;
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(420, 43);
            this.info.TabIndex = 13;
            this.info.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(125, 111);
            this.address.Multiline = true;
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(419, 53);
            this.address.TabIndex = 12;
            // 
            // slnm
            // 
            this.slnm.Depth = 0;
            this.slnm.Hint = "Last Name";
            this.slnm.Location = new System.Drawing.Point(389, 69);
            this.slnm.MouseState = MaterialSkin.MouseState.HOVER;
            this.slnm.Name = "slnm";
            this.slnm.PasswordChar = '\0';
            this.slnm.SelectedText = "";
            this.slnm.SelectionLength = 0;
            this.slnm.SelectionStart = 0;
            this.slnm.Size = new System.Drawing.Size(146, 23);
            this.slnm.TabIndex = 9;
            this.slnm.UseSystemPasswordChar = false;
            this.slnm.Click += new System.EventHandler(this.MaterialSingleLineTextField3_Click);
            // 
            // smnm
            // 
            this.smnm.Depth = 0;
            this.smnm.Hint = "Middle Name";
            this.smnm.Location = new System.Drawing.Point(209, 69);
            this.smnm.MouseState = MaterialSkin.MouseState.HOVER;
            this.smnm.Name = "smnm";
            this.smnm.PasswordChar = '\0';
            this.smnm.SelectedText = "";
            this.smnm.SelectionLength = 0;
            this.smnm.SelectionStart = 0;
            this.smnm.Size = new System.Drawing.Size(143, 23);
            this.smnm.TabIndex = 8;
            this.smnm.UseSystemPasswordChar = false;
            this.smnm.Click += new System.EventHandler(this.MaterialSingleLineTextField2_Click);
            // 
            // sfnm
            // 
            this.sfnm.Depth = 0;
            this.sfnm.Hint = "First Name";
            this.sfnm.Location = new System.Drawing.Point(22, 69);
            this.sfnm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sfnm.Name = "sfnm";
            this.sfnm.PasswordChar = '\0';
            this.sfnm.SelectedText = "";
            this.sfnm.SelectionLength = 0;
            this.sfnm.SelectionStart = 0;
            this.sfnm.Size = new System.Drawing.Size(156, 23);
            this.sfnm.TabIndex = 7;
            this.sfnm.UseSystemPasswordChar = false;
            this.sfnm.Click += new System.EventHandler(this.materialSingleLineTextField1_Click);
            // 
            // materialLabel7
            // 
            this.materialLabel7.AutoSize = true;
            this.materialLabel7.Depth = 0;
            this.materialLabel7.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel7.Location = new System.Drawing.Point(334, 185);
            this.materialLabel7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel7.Name = "materialLabel7";
            this.materialLabel7.Size = new System.Drawing.Size(77, 19);
            this.materialLabel7.TabIndex = 6;
            this.materialLabel7.Text = "Pin Code :";
            this.materialLabel7.Click += new System.EventHandler(this.MaterialLabel7_Click);
            // 
            // materialLabel6
            // 
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel6.Location = new System.Drawing.Point(19, 310);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(90, 19);
            this.materialLabel6.TabIndex = 5;
            this.materialLabel6.Text = "Supplier Of :";
            this.materialLabel6.Click += new System.EventHandler(this.MaterialLabel6_Click);
            // 
            // materialLabel5
            // 
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel5.Location = new System.Drawing.Point(18, 273);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(94, 19);
            this.materialLabel5.TabIndex = 4;
            this.materialLabel5.Text = "Contact No :";
            this.materialLabel5.Click += new System.EventHandler(this.MaterialLabel5_Click);
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(19, 228);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(73, 19);
            this.materialLabel4.TabIndex = 3;
            this.materialLabel4.Text = "Email ID :";
            this.materialLabel4.Click += new System.EventHandler(this.MaterialLabel4_Click);
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(19, 181);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(43, 19);
            this.materialLabel3.TabIndex = 2;
            this.materialLabel3.Text = "City :";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(18, 126);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(72, 19);
            this.materialLabel2.TabIndex = 1;
            this.materialLabel2.Text = "Address :";
            this.materialLabel2.Click += new System.EventHandler(this.MaterialLabel2_Click);
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(19, 34);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(89, 19);
            this.materialLabel1.TabIndex = 0;
            this.materialLabel1.Text = "Supplier ID :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 454);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(571, 167);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.materialRaisedButton7);
            this.groupBox2.Controls.Add(this.materialSingleLineTextField9);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Location = new System.Drawing.Point(589, 79);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 185);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // materialRaisedButton7
            // 
            this.materialRaisedButton7.Depth = 0;
            this.materialRaisedButton7.Location = new System.Drawing.Point(64, 130);
            this.materialRaisedButton7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton7.Name = "materialRaisedButton7";
            this.materialRaisedButton7.Primary = true;
            this.materialRaisedButton7.Size = new System.Drawing.Size(105, 31);
            this.materialRaisedButton7.TabIndex = 4;
            this.materialRaisedButton7.Text = "Search by id";
            this.materialRaisedButton7.UseVisualStyleBackColor = true;
            this.materialRaisedButton7.Click += new System.EventHandler(this.materialRaisedButton7_Click);
            // 
            // materialSingleLineTextField9
            // 
            this.materialSingleLineTextField9.Depth = 0;
            this.materialSingleLineTextField9.Hint = "";
            this.materialSingleLineTextField9.Location = new System.Drawing.Point(2, 8);
            this.materialSingleLineTextField9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSingleLineTextField9.Name = "materialSingleLineTextField9";
            this.materialSingleLineTextField9.PasswordChar = '\0';
            this.materialSingleLineTextField9.SelectedText = "";
            this.materialSingleLineTextField9.SelectionLength = 0;
            this.materialSingleLineTextField9.SelectionStart = 0;
            this.materialSingleLineTextField9.Size = new System.Drawing.Size(49, 23);
            this.materialSingleLineTextField9.TabIndex = 3;
            this.materialSingleLineTextField9.Text = "Search";
            this.materialSingleLineTextField9.UseSystemPasswordChar = false;
            // 
            // comboBox1
            // 
            this.comboBox1.DisplayMember = "Id";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(64, 30);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(120, 21);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.ValueMember = "Id";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.materialRaisedButton8);
            this.groupBox3.Controls.Add(this.materialSingleLineTextField8);
            this.groupBox3.Controls.Add(this.materialRaisedButton4);
            this.groupBox3.Controls.Add(this.materialRaisedButton5);
            this.groupBox3.Controls.Add(this.materialRaisedButton3);
            this.groupBox3.Controls.Add(this.materialRaisedButton2);
            this.groupBox3.Controls.Add(this.materialRaisedButton1);
            this.groupBox3.Location = new System.Drawing.Point(589, 270);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 351);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // materialRaisedButton8
            // 
            this.materialRaisedButton8.Depth = 0;
            this.materialRaisedButton8.Location = new System.Drawing.Point(62, 148);
            this.materialRaisedButton8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton8.Name = "materialRaisedButton8";
            this.materialRaisedButton8.Primary = true;
            this.materialRaisedButton8.Size = new System.Drawing.Size(87, 30);
            this.materialRaisedButton8.TabIndex = 20;
            this.materialRaisedButton8.Text = "Update";
            this.materialRaisedButton8.UseVisualStyleBackColor = true;
            this.materialRaisedButton8.Click += new System.EventHandler(this.materialRaisedButton8_Click);
            // 
            // materialSingleLineTextField8
            // 
            this.materialSingleLineTextField8.Depth = 0;
            this.materialSingleLineTextField8.Hint = "";
            this.materialSingleLineTextField8.Location = new System.Drawing.Point(6, 19);
            this.materialSingleLineTextField8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSingleLineTextField8.Name = "materialSingleLineTextField8";
            this.materialSingleLineTextField8.PasswordChar = '\0';
            this.materialSingleLineTextField8.SelectedText = "";
            this.materialSingleLineTextField8.SelectionLength = 0;
            this.materialSingleLineTextField8.SelectionStart = 0;
            this.materialSingleLineTextField8.Size = new System.Drawing.Size(65, 23);
            this.materialSingleLineTextField8.TabIndex = 4;
            this.materialSingleLineTextField8.Text = "Action";
            this.materialSingleLineTextField8.UseSystemPasswordChar = false;
            // 
            // materialRaisedButton4
            // 
            this.materialRaisedButton4.Depth = 0;
            this.materialRaisedButton4.Location = new System.Drawing.Point(62, 301);
            this.materialRaisedButton4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton4.Name = "materialRaisedButton4";
            this.materialRaisedButton4.Primary = true;
            this.materialRaisedButton4.Size = new System.Drawing.Size(87, 29);
            this.materialRaisedButton4.TabIndex = 3;
            this.materialRaisedButton4.Text = "Exit";
            this.materialRaisedButton4.UseVisualStyleBackColor = true;
            this.materialRaisedButton4.Click += new System.EventHandler(this.materialRaisedButton4_Click);
            // 
            // materialRaisedButton5
            // 
            this.materialRaisedButton5.Depth = 0;
            this.materialRaisedButton5.Location = new System.Drawing.Point(62, 203);
            this.materialRaisedButton5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton5.Name = "materialRaisedButton5";
            this.materialRaisedButton5.Primary = true;
            this.materialRaisedButton5.Size = new System.Drawing.Size(87, 28);
            this.materialRaisedButton5.TabIndex = 1;
            this.materialRaisedButton5.Text = "Display";
            this.materialRaisedButton5.UseVisualStyleBackColor = true;
            this.materialRaisedButton5.Click += new System.EventHandler(this.materialRaisedButton5_Click);
            // 
            // materialRaisedButton3
            // 
            this.materialRaisedButton3.Depth = 0;
            this.materialRaisedButton3.Location = new System.Drawing.Point(62, 102);
            this.materialRaisedButton3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton3.Name = "materialRaisedButton3";
            this.materialRaisedButton3.Primary = true;
            this.materialRaisedButton3.Size = new System.Drawing.Size(87, 26);
            this.materialRaisedButton3.TabIndex = 2;
            this.materialRaisedButton3.Text = "Delete";
            this.materialRaisedButton3.UseVisualStyleBackColor = true;
            this.materialRaisedButton3.Click += new System.EventHandler(this.materialRaisedButton3_Click_1);
            // 
            // materialRaisedButton2
            // 
            this.materialRaisedButton2.Depth = 0;
            this.materialRaisedButton2.Location = new System.Drawing.Point(62, 253);
            this.materialRaisedButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton2.Name = "materialRaisedButton2";
            this.materialRaisedButton2.Primary = true;
            this.materialRaisedButton2.Size = new System.Drawing.Size(87, 30);
            this.materialRaisedButton2.TabIndex = 1;
            this.materialRaisedButton2.Text = "Reset";
            this.materialRaisedButton2.UseVisualStyleBackColor = true;
            this.materialRaisedButton2.Click += new System.EventHandler(this.materialRaisedButton2_Click_1);
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(62, 57);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(87, 26);
            this.materialRaisedButton1.TabIndex = 0;
            this.materialRaisedButton1.Text = "Save";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click_1);
            // 
            // Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 633);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Supplier";
            this.Text = "Supplier";
            this.Load += new System.EventHandler(this.Supplier_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MaterialSkin.Controls.MaterialLabel materialLabel7;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialSingleLineTextField slnm;
        private MaterialSkin.Controls.MaterialSingleLineTextField smnm;
        private MaterialSkin.Controls.MaterialSingleLineTextField sfnm;
        private System.Windows.Forms.TextBox info;
        private System.Windows.Forms.TextBox address;
        private MaterialSkin.Controls.MaterialSingleLineTextField contact;
        private MaterialSkin.Controls.MaterialSingleLineTextField emailid;
        private MaterialSkin.Controls.MaterialSingleLineTextField pin;
        private MaterialSkin.Controls.MaterialSingleLineTextField city;
        private MaterialSkin.Controls.MaterialSingleLineTextField sid;
        private System.Windows.Forms.GroupBox groupBox2;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton7;
        private MaterialSkin.Controls.MaterialSingleLineTextField materialSingleLineTextField9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton8;
        private MaterialSkin.Controls.MaterialSingleLineTextField materialSingleLineTextField8;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton4;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton5;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton3;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton2;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
    }
}