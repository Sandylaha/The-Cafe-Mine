﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class Makeorder : MaterialSkin.Controls.MaterialForm
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\rex\Documents\Visual Studio 2012\Projects\The Cafe Mine\The Cafe Mine\Cafe.mdf;Integrated Security=True;Connect Timeout=30");
        SqlDataAdapter da;
        DataTable dt;
        public Makeorder()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);

        }

        private void Makeorder_Load(object sender, EventArgs e)
        {
            UserLoad();
            ProductLoad();
            // TODO: This line of code loads data into the 'cafeDataSet5.stock' table. You can move, or remove it, as needed.
        }
        public void UserLoad(){
            con.Open();
            da = new SqlDataAdapter("Select * From [dbo].[user]", con);
            dt = new DataTable();
            da.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["fnm"] = "Select Name";
            dt.Rows.InsertAt(dr, 0);
            comboBox3.ValueMember = "fnm";
            comboBox3.DisplayMember = "fnm";
            comboBox3.DataSource = dt;
            con.Close();

        }
        public void ProductLoad()
        {
            con.Open();
            da = new SqlDataAdapter("Select * From [dbo].[stock]", con);
            dt = new DataTable();
            da.Fill(dt);
            DataRow dr = dt.NewRow();
            dr["Pname"] = "Select Product";
            dt.Rows.InsertAt(dr, 0);
            comboBox4.ValueMember = "Pname";
            comboBox4.DisplayMember = "Pname";
            comboBox4.DataSource = dt;
            con.Close();

        }


        private void Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MaterialLabel3_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel2_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MaterialLabel6_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel5_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel4_Click(object sender, EventArgs e)
        {

        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MaterialLabel1_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into [dbo].[orders] values('" + materialSingleLineTextField3.Text + "','" + comboBox3.SelectedValue + "','" + comboBox4.SelectedValue + "','"+materialSingleLineTextField11.Text+"','" + materialSingleLineTextField9.Text + "','" + materialSingleLineTextField10.Text + "','" + materialSingleLineTextField1.Text + "','" + materialSingleLineTextField2.Text + "','" + materialSingleLineTextField4.Text + "','" + dateTimePicker1.Text + "','" + materialSingleLineTextField5.Text + "','" + materialSingleLineTextField7.Text + "','" + materialSingleLineTextField6.Text + "','" + materialSingleLineTextField8.Text + "')";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("record inserted successfully");
        }

        private void MaterialRaisedButton3_Click(object sender, EventArgs e)
        {
            Payments pay = new Payments();
            pay.ShowDialog();
        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel8_Click(object sender, EventArgs e)
        {

        }

        private void MaterialLabel11_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField6_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MaterialLabel9_Click(object sender, EventArgs e)
        {

        }

        private void MaterialSingleLineTextField5_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField10_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {


            string query = "select * from [dbo].[user] where fnm = '"+comboBox3.Text+"' ";
            SqlCommand cmd = new SqlCommand( query,con);
            SqlDataReader dbr;
            try
                {
                    con.Open();
                dbr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while(dbr.Read())
                    {
                     string cont = (string)dbr["con"].ToString();
                    string addr = (string) dbr["txt"] ;
                    string gen = (string)dbr["gend"];

                    
                   

                    materialSingleLineTextField9.Text = cont;
                    materialSingleLineTextField10.Text = addr;
                    materialSingleLineTextField11.Text = cont;


                   

                            }
            }
           catch(Exception es)
                {
                    MessageBox.Show(es.Message);
        }
            con.Close();


}

        

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void materialLabel10_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton6_Click(object sender, EventArgs e)
        {
            decimal price, quant;
            price = Convert.ToDecimal(materialSingleLineTextField1.Text);
            quant = Convert.ToDecimal(materialSingleLineTextField2.Text);

            decimal res = (price * quant);
            materialSingleLineTextField4.Text = res.ToString();
        }

        private void materialRaisedButton4_Click(object sender, EventArgs e)
        {
            comboBox3.SelectedValue = "";
            comboBox4.SelectedValue="";
            materialSingleLineTextField9.Text=""; 
            materialSingleLineTextField1.Text="";
            materialSingleLineTextField10.Text="";
            materialSingleLineTextField2.Text="";
            materialSingleLineTextField4.Text="";
            materialSingleLineTextField5.Text="";
            materialSingleLineTextField7.Text="";
            materialSingleLineTextField6.Text="";
            materialSingleLineTextField8.Text="";
            dateTimePicker1.Format = DateTimePickerFormat.Short;

        }

        private void materialRaisedButton1_Click_1(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton1_Click_2(object sender, EventArgs e)
        {
            decimal price, quant;
            price = Convert.ToDecimal(materialSingleLineTextField1.Text);
            quant = Convert.ToDecimal(materialSingleLineTextField2.Text);

            decimal res = (price * quant);
            decimal gstval = Convert.ToDecimal(materialSingleLineTextField7.Text);
            decimal pregst = res + (res * (gstval / 100));
            decimal gst = pregst - res;
            decimal vatval = Convert.ToDecimal(materialSingleLineTextField5.Text);
            decimal vat = res * (vatval / 100);
            decimal disval = Convert.ToDecimal(materialSingleLineTextField5.Text);
            decimal dis = (res * disval / 100);
            decimal finalam = (res + gst + vat) - dis;
            materialSingleLineTextField8.Text = finalam.ToString();
        }

        private void materialSingleLineTextField11_Click(object sender, EventArgs e)
        {

        }
    }
}
