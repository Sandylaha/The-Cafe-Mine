﻿namespace The_Cafe_Mine
{
    partial class Beverages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cafeDataSet6 = new The_Cafe_Mine.CafeDataSet6();
            this.beveragesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.beveragesTableAdapter = new The_Cafe_Mine.CafeDataSet6TableAdapters.beveragesTableAdapter();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cafeDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beveragesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 115);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(733, 403);
            this.dataGridView1.TabIndex = 6;
            // 
            // cafeDataSet6
            // 
            this.cafeDataSet6.DataSetName = "CafeDataSet6";
            this.cafeDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // beveragesBindingSource
            // 
            this.beveragesBindingSource.DataMember = "beverages";
            this.beveragesBindingSource.DataSource = this.cafeDataSet6;
            // 
            // beveragesTableAdapter
            // 
            this.beveragesTableAdapter.ClearBeforeFill = true;
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(352, 84);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(75, 25);
            this.materialRaisedButton1.TabIndex = 8;
            this.materialRaisedButton1.Text = "Insert";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // Beverages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 627);
            this.Controls.Add(this.materialRaisedButton1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Beverages";
            this.Text = "Beverages";
            this.Load += new System.EventHandler(this.Beverages_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cafeDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beveragesBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CafeDataSet6 cafeDataSet6;
        private System.Windows.Forms.BindingSource beveragesBindingSource;
        private CafeDataSet6TableAdapters.beveragesTableAdapter beveragesTableAdapter;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
    }
}