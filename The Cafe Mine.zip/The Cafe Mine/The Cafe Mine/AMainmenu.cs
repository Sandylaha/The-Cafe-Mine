﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cafe_Mine
{
    public partial class AMainmenu : Form
    {
        public AMainmenu()
        {
            InitializeComponent();
        }

        private void Mainmenu_Load(object sender, EventArgs e)
        {

            timer1.Start();
            label6.Text= DateTime.Now.ToLongDateString();
            label7.Text= DateTime.Now.ToLongTimeString();
        }

        private void MaterialRaisedButton3_Click(object sender, EventArgs e)
        {
            Beverages bev = new Beverages();
            bev.ShowDialog();
        }

        private void MaterialRaisedButton4_Click(object sender, EventArgs e)
        {
            Stock stk = new Stock();
            stk.ShowDialog();
        }

        private void MaterialRaisedButton7_Click(object sender, EventArgs e)
        {
            Orders ord = new Orders();
            ord.ShowDialog();
        }

        private void MaterialRaisedButton2_Click(object sender, EventArgs e)
        {
            URegister reg = new URegister();
            reg.ShowDialog();
        }

        private void MaterialRaisedButton1_Click(object sender, EventArgs e)
        {
            ARegister reg = new ARegister();
            reg.ShowDialog();
        }

        private void MaterialRaisedButton5_Click(object sender, EventArgs e)
        {
            Supplier sup = new Supplier();
            sup.ShowDialog();
        }

        private void MaterialRaisedButton6_Click(object sender, EventArgs e)
        {
            Email em = new Email();
            em.ShowDialog();
        }

        private void MaterialRaisedButton9_Click(object sender, EventArgs e)
        {
            Payments pay = new Payments();
            pay.ShowDialog();
        }

        private void MaterialRaisedButton12_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        private void MaterialRaisedButton10_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void GroupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void PictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void MaterialRaisedButton11_Click(object sender, EventArgs e)
        {
           /* Report rep = new Report();
            rep.ShowDialog();*/
        }

        private void MaterialRaisedButton8_Click(object sender, EventArgs e)
        {
            Report bil = new Report();
            bil.ShowDialog();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            label7.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Makeorder mo = new Makeorder();
            mo.ShowDialog();
        }

        private void Label7_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
